jQuery( document ).ready( function () { 
	
	jQuery( '.aviasales_info_toggle' ).live( 'click', function () {
		jQuery( this ).parent().parent().find( '.aviasales_info_to_toggle' ).slideToggle();
		return false;
	} );
	
} );