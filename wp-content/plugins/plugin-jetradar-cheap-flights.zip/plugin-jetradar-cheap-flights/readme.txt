=== Plugin Jetradar Cheap Flights ===
Contributors: travelpayouts
Donate link: http://www.travelpayouts.com
Tags: flights, aviasales, jetradar, travelpayouts, travel, airfare, airfares, affiliate marketing, affiliate, affiliates, flights, airtickets, air tickets, tickets
Requires at least: 3.0.0
Tested up to: 3.5.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Find and book cheap flights with this useful flight search plugin from Jetradar.com.

== Description ==

**The plugin is outdated and unsupported.**

**Please use our new version of the plugin in WP directory - [Travelpayouts](https://wordpress.org/plugins/travelpayouts/)**

Join Travelpayouts [Travel Affiliate Program](https://www.travelpayouts.com/?utm_source=wp_org&utm_medium=jetradar_plugin) to make money in travel.

Find and book cheap flights with this useful flight search plugin from Jetradar.com. Search and compare prices through dozens of travel websites with fewer clicks. Earn money with each purchase of airline tickets made by visitors of your website.

== Installation ==

1. Join the TravelPayouts 
2. Download and unzip the plugin to the /wp-content/plugins/ directory
3. Activate the plugin through the Plugins menu in WordPress
4. Configure the settings at the administration menu >> Appearance >> Widgets.
5. Congratulations, the plugin is ready to go! Get 60% to 70% from TravelPayouts revenue for each flight's booking.

== Remove plugin ==

1. Deactivate plugin through the 'Plugins' menu in WordPress
2. Delete plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

Just visit http://support.travelpayouts.com/forums for any questions.

== Screenshots ==

1. Administrative form
2. Widget example

== Changelog ==

= 2.0.4 =
- Minor bugfix

= 2.0.3 =
- Adding colorpickers for search forms

= 2.0.2 =
- First plugin release.

== Upgrade Notice ==

= 2.0.2 =
- First plugin release.